<template>
  <div class="div2">
    <el-card class="box-card">
      <h2>注册</h2>
      <el-form
        :model="ruleForm"
        status-icon
        :rules="rules"
        ref="ruleForm"
        label-position="left"
        label-width="80px"
        class="demo-ruleForm"
      >
        <el-form-item label="用户名" prop="uname">
          <el-input v-model="ruleForm.uname" class="registerInput"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="pass">
          <el-input
            type="password"
            v-model="ruleForm.pass"
            autocomplete="off"
            class="registerInput"
          ></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="password">
          <el-input
            type="password"
            v-model="ruleForm.password"
            autocomplete="off"
            class="registerInput"
          ></el-input>
        </el-form-item>
      </el-form>
      <div class="btnGroup">
        <el-button type="primary" @click="submitForm('ruleForm')"
          >提交</el-button
        >
        <el-button @click="resetForm('ruleForm')">重置</el-button>
        <el-button @click="goBack">返回</el-button>
      </div>
    </el-card>
  </div>
</template>
  
  <script>
import axios from "axios";
export default {
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else {
        if (this.ruleForm.checkPass !== "") {
          this.$refs.ruleForm.validateField("checkPass");
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.ruleForm.pass) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      ruleForm: {
        uname: "",
        pass: "",
        password: "",
      },
      rules: {
        uname: [
          { required: true, message: "用户名不能为空！", trigger: "blur" },
        ],
        pass: [{ required: true, validator: validatePass, trigger: "blur" }],
        password: [
          { required: true, validator: validatePass2, trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          axios
            .post("http://localhost:8080/api/register", {
              username: this.ruleForm.uname,
              password: this.ruleForm.password,
            })
            .then((response) => {
              // 处理成功的响应
              console.log(response);
              if (response.data.code == 1) {
                this.$router.push({
                  name: "login",
                  query: { refresh: new Date().getTime() },
                });
                this.$message({
                  message: "注册成功",
                  type: "success",
                });
              } else {
                this.$message.error("该用户已存在");
              }
            })
            .catch((error) => {
              // 处理错误响应
              console.error(error);
            });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    goBack() {
      this.$router.go(-1);
    },
  },
};
</script>
  
  <style scoped>
.login-from {
  margin: auto auto;
}
.box-card {
  display: flex;
  flex-direction: column;
  max-width: 400px; /* 设置最大宽度，可以根据需要调整 */
  width: 100%; /* 默认宽度为100%，但不超过max-width */
  padding: 20px; /* 可选的内边距 */
  box-sizing: border-box; /* 确保padding和border不增加元素的总宽度和高度 */
  background-color: #f5f5f5; /* 可选的背景颜色 */
}
.div2 {
  display: grid;
  place-items: center; /* 这将水平和垂直居中 */
  height: 100%; /* 或者你希望的高度 */
}
.registerInput{
  width: 100%;
  height: 100%;
}
</style>