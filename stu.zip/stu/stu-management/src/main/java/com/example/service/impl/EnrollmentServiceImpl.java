package com.example.service.impl;

import com.example.mapper.EnrollmentMapper;
import com.example.pojo.EnrollCourseJoin;
import com.example.pojo.Enrollment;
import com.example.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnrollmentServiceImpl implements EnrollmentService {

    @Autowired
    private EnrollmentMapper enrollmentMapper;

    @Override
    public List<EnrollCourseJoin> listJoin(String stuName, String courseName) {
        return enrollmentMapper.listJoin(stuName, courseName);
    }

    @Override
    public void insert(Enrollment enrollment) {
        Integer enNum = enrollmentMapper.getEnNum(enrollment.getCourseId());
        Integer maxNum = enrollmentMapper.getMaxNum(enrollment.getCourseId());
        Integer stuNum = enrollmentMapper.getStuNum(enrollment.getCourseId());
        if (enNum < maxNum) {
            enrollmentMapper.plus1(enrollment.getCourseId());
            enNum = enNum + 1;
            enrollmentMapper.insert(enrollment);
            if (enNum >= stuNum && enNum < maxNum) {
                enrollmentMapper.setStatus("开课", enrollment.getCourseId());
            } else if (enNum == maxNum) {
                enrollmentMapper.setStatus("满课", enrollment.getCourseId());
            }

        }


    }

    @Override
    public void delete(Enrollment enrollment) {
        Integer enNum = enrollmentMapper.getEnNum(enrollment.getCourseId());
        Integer stuNum = enrollmentMapper.getStuNum(enrollment.getCourseId());
        if (enNum - 1 > 0) {
            enrollmentMapper.minus1(enrollment.getCourseId());
            enNum = enNum - 1;
            enrollmentMapper.delete(enrollment);
            if (enNum < stuNum) {
                enrollmentMapper.setStatus("未开课", enrollment.getCourseId());
            }

        }

    }

    @Override
    public Integer flag(String stuName, Integer courseId) {
        Enrollment enrollment = enrollmentMapper.flag(stuName, courseId);
        String status = enrollmentMapper.getStatusByCourseId(courseId);
        if (enrollment == null && !status.equals("满课")) {
            return 0;
        } else if (enrollment == null && status.equals("满课")) {
            return -1;
        } else if(enrollment != null && status.equals("满课")){
            return 1;
        }else {
            return 1;
        }
    }
}
