package com.example.service;

import com.example.pojo.EnrollCourseJoin;
import com.example.pojo.Enrollment;

import java.util.List;

public interface EnrollmentService {
    List<EnrollCourseJoin> listJoin(String stuName, String courseName);

    void insert(Enrollment enrollment);

    void delete(Enrollment enrollment);

    Integer flag(String stuName ,Integer courseId);
}
