package com.example.service;

import com.example.pojo.Lookup;

import java.util.List;

public interface SmmLookupService {

    List<Lookup> list();
}
