package com.example.service;

import com.example.pojo.DeptClassJoin;

import java.util.List;

public interface DeptClassJoinService {
    List<DeptClassJoin> list();
}
